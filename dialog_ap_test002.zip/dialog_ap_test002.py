import socket
import json
import time

class SpeechRecognitionController(object):
    def __init__(self, ip, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((ip, port))

    def disconnect(self):
        self.sock.close()

    def send_command(self,command):
        command_ln = command + "\n"
        self.sock.send(command_ln.encode('utf-8'))
        print(command_ln.encode('utf-8'))

    def sppech_get(self):
        msg_dec = ""
        while msg_dec.startswith('result:') == False:
            msg = self.sock.recv(1024)
            msg_dec = msg.decode("utf-8")
            if msg_dec.startswith('result:') == True:
                return msg_dec
                break
            time.sleep(0.5)

class SpeechGenerator(object):
    def __init__(self, ip, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((ip, port))

    def disconnect(self):
        self.sock.close()

    def send_command(self,command):
        command_ln = command + "\n"
        self.sock.send(command_ln.encode('utf-8'))

    def say_singleword(self,message):
        m_tag = "<speak><amazon:effect phonation='soft' vocal-tract-length='-15%'>{}</amazon:effect></speak>"
        message_f = m_tag.format(message)
        message_dict = {"engine":"POLLY-SSML", "speaker":"Mizuki",  "text":message_f}
        message_json = json.dumps(message_dict)
        #音声メッセージを発信
        robot_SpeechGenerator.send_command(message_json)

    def say_doubleword(self,message_1,message_2):
        m_tag = "<speak><amazon:effect phonation='soft' vocal-tract-length='-15%'><s>{}</s><s>{}</s></amazon:effect></speak>"
        message_3 = m_tag.format(message_1, message_2)
        message_dict = {"engine":"POLLY-SSML", "speaker":"Mizuki", "text":message_3}
        message_json = json.dumps(message_dict)
        #音声メッセージを発信
        robot_SpeechGenerator.send_command(message_json)



if __name__ == "__main__":

#各システムに接続
    robot_SpeechRecognition_controller = SpeechRecognitionController("192.168.1.10", 8888)
    robot_SpeechGenerator = SpeechGenerator("192.168.1.10", 3456)

#音声認識停止
    robot_SpeechRecognition_controller.send_command("stop")

#挨拶をする。晩御飯のメニュー質問
    message_1 = "おかえりなさい.今日の晩ご飯は何がいい."
    message_2 = "イタリアンかな.それとも中華かな."
    robot_SpeechGenerator.say_doubleword(message_1, message_2)


#音声認識開始
    time.sleep(6)
    robot_SpeechRecognition_controller.send_command("start")

#音声情報（文字情報）を取得
    msg_d = robot_SpeechRecognition_controller.sppech_get()
    print("msg_d:" + msg_d)
    #音声メッセージを編集（１）
    target = "confidence:"
    idx = msg_d.find(target)
    #7桁以降と、「confidence:」より後ろは削除
    message = msg_d[7:idx].strip()
    print("message(1):" + message)

#音声情報（文字情報）の判定
    Chinese_cooking_list  = ['中華', '中華料理', 'チャイニーズ']
    Itarian_cooking_list   = ['イタリアン', 'イタリア', 'パスタ', 'ピザ']
    if message in Chinese_cooking_list:
        message_c = "やっぱり中華がいいよね　餃子にしょう" 
        robot_SpeechGenerator.say_singleword(message_c)
    elif message in Itarian_cooking_list:
        message_f = "わかった　イタリアンね　パスタにしょう"
        robot_SpeechGenerator.say_singleword(message_f)
    else:
        message_R = "なに　もう一度言ってよ"
        robot_SpeechGenerator.say_singleword(message_R)


#各システム切断
    robot_SpeechRecognition_controller.disconnect()
    robot_SpeechGenerator.disconnect()
    print('\nEnd')



