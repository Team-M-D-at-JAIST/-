import socket
import json
import time

class SpeechRecognitionController(object):
    def __init__(self, ip, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((ip, port))

    def disconnect(self):
        self.sock.close()

    def send_command(self,command):
        command_ln = command + "\n"
        self.sock.send(command_ln.encode('utf-8'))

    def sppech_get(self):
        msg_dec = ""
        while msg_dec.startswith('result:') == False:
            msg = self.sock.recv(1024)
            msg_dec = msg.decode("utf-8")
            if msg_dec.startswith('result:') == True:
                return msg_dec
                break
            time.sleep(0.5)

class SpeechGenerator(object):
    def __init__(self, ip, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((ip, port))

    def disconnect(self):
        self.sock.close()

    def send_command(self,command):
        command_ln = command + "\n"
        self.sock.send(command_ln.encode('utf-8'))



if __name__ == "__main__":

#各システムに接続
    robot_SpeechRecognition_controller = SpeechRecognitionController("192.168.1.10", 8888)
    robot_SpeechGenerator = SpeechGenerator("192.168.1.10", 3456)


#テストで色々試してみる（言ったことばをそのまま返す）-------
#Speech Recognition Serever より音声メッセージを受信
    msg_d = robot_SpeechRecognition_controller.sppech_get()
    print("msg_d:" + msg_d)

    #音声メッセージを編集（１）
    target = "confidence:"
    idx = msg_d.find(target)
    #7桁以降と、「confidence:」より後ろは削除
    message = msg_d[7:idx].strip()
    print("message(1):" + message)

    #音声メッセージを編集（２） Amazon Polly SSMLタグamazon:effect phonation=“soft“とvocal-tract-length=”-15%”をつける
    m_tag = "<speak><amazon:effect phonation='soft' vocal-tract-length='-15%'>{}</amazon:effect></speak>"
    message2 = m_tag.format(message)
    print("message(2):" + message2)

    #音声メッセージを編集（３） json形式に変換
    message3 = {"engine":"POLLY-SSML", "speaker":"Mizuki",  "text":message2}
    message_json = json.dumps(message3)

    #音声メッセージを発信
    robot_SpeechGenerator.send_command(message_json)
#--------------------------------------------


#各システム切断
    robot_SpeechRecognition_controller.disconnect()
    robot_SpeechGenerator.disconnect()
    print('\nEnd')

