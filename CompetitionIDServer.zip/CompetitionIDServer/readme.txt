本プログラムは対話コンペティションで用いられる観光地ID管理サーバです。
参加者のプログラムはTCP/IP通信を行い、"GET\n"コマンドを送信することで、現在選択されている観光地IDのリストと推薦観光地IDをJson形式で受信します。
selected_idフィールドに現在選択されている観光地IDのリスト、recommended_idフィールドに推薦観光地IDが格納されています。
通信データ例 : {"selected_id":["80101916","80028943"],"recommended_id":"80028943"}
また、対話開始（観光地選択データが本プログラムに送信された時点）から対話時間（本番では5分30秒）が経過した時点で、"GET\n"コマンドを一度送信しているクライアントには対話終了コマンドがJson形式で送信されます。
elapsed_timeフィールドに経過時間、operationフィールドにコマンドの種類、conversation_ruleフィールドに対話ルールの種類が格納されています。
対話終了コマンドでは、operationフィールドは"TIMER"、conversation_ruleフィールドは"CONVERSATION_END"となります。
通信データ例 : {"elapsed_time":330000,"operation":"TIMER","conversation_rule":"CONVERSATION_END"}


本番環境以外のテスト動作時には、デフォルトで選択される観光地IDが使用されることになります。
デフォルトで選択される観光地IDは、setting.propertiesのdefault_id_1、default_id_2の値を書き換えることで変更することができます。デフォルトの推薦観光地IDはdefault_id_1の値となります。
対話終了コマンド受信のテストを行う場合、setting.propertiesのstart_timer_at_runtimeの値をtrueにすることで、本プログラム起動時から対話時間経過後に対話終了コマンドが送信されます。
対話時間は、setting.propertiesのconversation_end_timeの値をミリ秒単位で設定することで変更できます。
また、観光地ID管理サーバのTCPサーバポートは、setting.propertiesのtcp_server_portの値を書き換えることで変更することができます。
