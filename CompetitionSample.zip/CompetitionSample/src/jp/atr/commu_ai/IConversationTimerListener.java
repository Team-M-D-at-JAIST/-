package jp.atr.commu_ai;

public interface IConversationTimerListener {
	public void onConversationRule(String rule, long elapsedTime);
}
