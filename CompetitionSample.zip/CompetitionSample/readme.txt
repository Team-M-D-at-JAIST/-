本プログラムは対話コンペティションのサンプルプログラムです。対話コンペティション用の各プログラムとの通信を行い、基本的なインタラクションを構成します。
本プログラムはeclipse(https://www.eclipse.org/)用のJavaプロジェクトです。Java開発環境の構築は公式情報を参照してください。


ソースファイル概要
CompetitionSample.java
 - メインクラス。プログラムのエントリポイント。
TCPClient.java
 - TCP通信クライアントクラス
AbstractCommunicator.java
 - TCP通信を行う抽象クラス
SpeechGenerator.java
 - 音声合成制御クラス
SpeechRecognitionManager.java
 - 音声認識管理クラス
RobotBodyController.java
 - ロボットの動作制御クラス
RobotExpressionController.java
 - ロボットの表情制御クラス
FaceRecognitionManager.java
 - 顔認識管理クラス
JsonUtils.java
 - Json用のユーティリティクラス
SelectionIDConnector.java
 - ユーザが選択した観光地ID管理クラス
SightDataManager.java
 - 観光地データ管理クラス


サンプルインタラクション概要
サンプルインタラクションはCompetitionSampleクラスをJava applicationとして実行することで起動できます。
起動後は音声認識結果を参照し続け、その結果に従って各機能を実行します。具体的な処理記述はCompetitionSampleクラスのprocessメソッドを参照してください。


通信機能について
本プログラムで実装されているサンプルインタラクションは、対話コンペティション用のすべてのプログラムとの通信で構成されています。
setting.propertiesファイルで、それぞれの通信先プログラムのホスト名(もしくはIPアドレス)とポート番号を指定してください。
本プログラムで実装されている通信処理は以下のものになります。
・音声認識結果の受信
・顔認識結果の受信
・音声合成指令の送信
・表情生成指令の送信
・視線(頭の向き)指定指令の送信
・選択観光地ID、対話時間終了コマンドの受信
指令内容の構造は各通信先プログラムのプロトコルを参照してください。

