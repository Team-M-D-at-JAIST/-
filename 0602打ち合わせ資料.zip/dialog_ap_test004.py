import socket
import json
import time

class SpeechRecognitionController(object):
    def __init__(self, ip, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((ip, port))

    def disconnect(self):
        self.sock.close()

    def send_command(self,command):
        command_ln = command + "\n"
        self.sock.send(command_ln.encode('utf-8'))
        print(command_ln.encode('utf-8'))

    def sppech_get(self):
        msg_dec = ""
        while msg_dec.startswith('result:') == False:
            msg = self.sock.recv(1024)
            msg_dec = msg.decode("utf-8")
            if msg_dec.startswith('result:') == True:
                return msg_dec
                break
            time.sleep(0.5)

class SpeechGenerator(object):
    def __init__(self, ip, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((ip, port))

    def disconnect(self):
        self.sock.close()

    def send_command(self,command):
        command_ln = command + "\n"
        self.sock.send(command_ln.encode('utf-8'))

    def say_singleword(self,message):
        m_tag = "<speak><amazon:effect phonation='soft' vocal-tract-length='-15%'>{}</amazon:effect></speak>"
        message_f = m_tag.format(message)
        message_dict = {"engine":"POLLY-SSML", "speaker":"Mizuki",  "text":message_f}
        message_json = json.dumps(message_dict)
        #音声メッセージを発信
        robot_SpeechGenerator.send_command(message_json)

    def say_doubleword(self,message_1,message_2):
        m_tag = "<speak><amazon:effect phonation='soft' vocal-tract-length='-15%'><s>{}</s><s>{}</s></amazon:effect></speak>"
        message_3 = m_tag.format(message_1, message_2)
        message_dict = {"engine":"POLLY-SSML", "speaker":"Mizuki", "text":message_3}
        message_json = json.dumps(message_dict)
        #音声メッセージを発信
        robot_SpeechGenerator.send_command(message_json)

class RobotExpressionController(object):
    def __init__(self, ip, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((ip, port))

    def disconnect(self):
        self.sock.close()

    def send_command(self,command):
        command_ln = command + "\n"
        self.sock.send(command_ln.encode('utf-8'))

    def setExpression(self, exp_name):
        command = "expression " + exp_name
        self.send_command(command)

    def setMyExpression(self, exp_name):
        # 各内部状態(各パラメータ)を指定
        if exp_name == "smile":
            # ("笑顔"というよりは"にこやか"にさせたかった)
            param_list = [
                "valence 0.3",
                "arousal 0.2",
                "dominance 0.1"
            ]

        elif exp_name == "normal":
            # (平常？取りあえず全部0で)
            param_list = [
                "valence 0",
                "arousal 0",
                "dominance 0",
                "realIntention 0"
            ]

        # 上記で指定したパラメータに応じて表情を変化させる
        param_list.append("expression MoodBasedFACS")

        command = "\n".join(param_list)
        self.send_command(command)
        
    def set_brink(self):
        command = "blink"
        self.send_command(command)

    def create_mouth_shape(self, hiragana_list):
        FromHiragana_ToVouel = {
            'あ':'a', 'い':'i', 'う':'u', 'え':'e', 'お':'o',
            'か':'a', 'き':'i', 'く':'u', 'け':'e', 'こ':'o',
            'さ':'a', 'し':'i', 'す':'u', 'せ':'e', 'そ':'o',
            'た':'a', 'ち':'i', 'つ':'u', 'て':'e', 'と':'o',
            'な':'a', 'に':'i', 'ぬ':'u', 'ね':'e', 'の':'o',
            'は':'a', 'ひ':'i', 'ふ':'u', 'へ':'e', 'ほ':'o',
            'ま':'a', 'み':'i', 'む':'u', 'め':'e', 'も':'o',
            'や':'a', 'ゆ':'u', 'よ':'o',
            'ら':'a', 'り':'i', 'る':'u', 'れ':'e', 'ろ':'o',
            'わ':'a', 'を':'o', 'ん':'u',
            'が':'a', 'ぎ':'i', 'ぐ':'u', 'げ':'e', 'ご':'o',
            'ざ':'a', 'じ':'i', 'ず':'u', 'ぜ':'e', 'ぞ':'o',
            'だ':'a', 'ぢ':'i', 'づ':'u', 'で':'e', 'ど':'o',
            'ば':'a', 'び':'i', 'ぶ':'u', 'べ':'e', 'ぼ':'o',
            'ぱ':'a', 'ぴ':'i', 'ぷ':'u', 'ぺ':'e', 'ぽ':'o',
            'ぁ':'a', 'ぃ':'i', 'ぅ':'u', 'ぇ':'e', 'ぉ':'o',
            'っ':'u', 'ゃ':'a', 'ゅ':'u', 'ょ':'o', 'ゎ':'a',
            '　':'-', '。':'-', '、':'-', '？':'-', '！':'-',
            'ー':'-', '―':'-'
        }
        vouel_list = ""
        for word_h in hiragana_list:
            val = FromHiragana_ToVouel[word_h]
            vouel_list = vouel_list + val

        #robot_expression_controller.setMyExpression("smile")

        for word in vouel_list:
            if word == "a":
                robot_expression_controller.setExpression("mouth-a")
                time.sleep(0.13)
            elif word == "i":
                robot_expression_controller.setExpression("mouth-i")
                time.sleep(0.13)
            elif word == "i":
                robot_expression_controller.setExpression("mouth-u")
                time.sleep(0.13)
            elif word == "i":
                robot_expression_controller.setExpression("mouth-e")
                time.sleep(0.13)
            elif word == "i":
                robot_expression_controller.setExpression("mouth-o")
                time.sleep(0.13)
            else:
                time.sleep(0.13)

class RobotBodyController(object):
    def __init__(self, ip, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((ip, port))

    def disconnect(self):
        self.sock.close()

    def playMotion(self, motion_id):
        command = "playmotion=" + motion_id
        self.send_command(command)

    def setGaze(self, x, y, z):
        # 正面方向:z軸，右方向:x軸，上方向:y軸
        # (例)
        #   正面に向く: (0.0, 1.2, 1.5)
        #   右に向く:   (1.0, 1.2, 1.5)
        #   左に向く:   (-1.0, 1.2, 1.5)
        eye_command = self.createGazeCommand("EyeController", "", x, y, z)
        head_command = self.createGazeCommand("HeadController", "", x, y, z)
        self.send_command(eye_command)
        self.send_command(head_command)

    def setGazeToObject(self,object_name):
        eye_command = self.createGazeCommand("EyeController", object_name, 0, 0, 0)
        head_command = self.createGazeCommand("HeadController", object_name, 0, 0, 0)
        self.send_command(eye_command)
        self.send_command(head_command)

    def createGazeCommand(self,controller, object_name, x, y, z):
        command_json = {
            "id": controller,
            "motionTowardObject": object_name,
            "targetMotionMode": 2,
            "targetPoint": {"x": x,"y": y,"z": z},
            "translateSpeed": 2.0
        }
        return controller + "=" + json.dumps(command_json)

    def send_command(self,command):
        command_ln = command + "\n"
        self.sock.send(command_ln.encode('utf-8'))
        

if __name__ == "__main__":

#各システムに接続
    robot_SpeechRecognition_controller = SpeechRecognitionController("192.168.1.10", 8888)
    robot_SpeechGenerator = SpeechGenerator("192.168.1.10", 3456)
    robot_expression_controller = RobotExpressionController("192.168.1.10", 20000)
    robot_body_controller = RobotBodyController("192.168.1.10", 21000)


#音声認識停止
    robot_SpeechRecognition_controller.send_command("stop")

#smile 
    robot_expression_controller.setMyExpression("smile")

#顔（首）の動き、視線の動き 
    robot_body_controller.setGaze(0.0, 1.2, 1.5)
    #robot_body_controller.playMotion("greeting")
    #robot_body_controller.setGazeToObject("Sofa")

#挨拶をする。晩御飯のメニュー質問
    message_1 = "おかえりなさい、、、、、、きょうの晩ご飯は何がいい？"
    message_2 = "イタリアン？.それとも中華？."
    robot_SpeechGenerator.say_doubleword(message_1, message_2)
    #口の動きを生成
    message_1_hiragana = "おかえりなさい　きょうのばんごはんはなにがいい"
    robot_expression_controller.create_mouth_shape(message_1_hiragana)
    message_2_hiragana = "いたりあん？　　それともちゅうか？"
    robot_expression_controller.create_mouth_shape(message_2_hiragana)

#音声認識開始
    time.sleep(0.1)
    robot_SpeechRecognition_controller.send_command("start")

#音声情報（文字情報）を取得
    msg_d = robot_SpeechRecognition_controller.sppech_get()
    print("msg_d:" + msg_d)
    #音声メッセージを編集（１）
    target = "confidence:"
    idx = msg_d.find(target)
    #7桁以降と、「confidence:」より後ろは削除
    message = msg_d[7:idx].strip()
    print("message(1):" + message)

#音声認識停止
    #robot_SpeechRecognition_controller.send_command("stop")

#音声情報（文字情報）の判定
    Chinese_cooking_list  = ['中華', '中華料理', '中国料理', 'チャイニーズ']
    Itarian_cooking_list   = ['イタリアン', 'イタリア', 'パスタ', 'ピザ']

    whether_isaid = 0
    if whether_isaid == 0:
        for Chinese_cooking in Chinese_cooking_list:
            if Chinese_cooking in message:
                message_c = "うん、やっぱり中華がいいよね、、、、餃子にしょう"
                message_c_hiragana = "うん、やっぱりちゅうかがいいよね、、、、ぎょうざにしょう"
                robot_SpeechGenerator.say_singleword(message_c)
                #テスト
                robot_body_controller.playMotion("nod")
                robot_expression_controller.create_mouth_shape(message_c_hiragana)
                whether_isaid = 1
                message = ""
                
    if whether_isaid == 0:
        for Itarian_cooking in Itarian_cooking_list:
            if Itarian_cooking in message:
                message_c = "わかった　イタリアンね、、、パスタにしょう"
                message_c_hiragana = "わかった　いたりあんね、、、ぱすたにしょう"
                robot_SpeechGenerator.say_singleword(message_c)
                robot_expression_controller.create_mouth_shape(message_c_hiragana)
                whether_isaid = 1
                message = ""

    if whether_isaid == 0:
        message_R = "なに？、、もう一度言って？"
        message_R_hiragana = "なに？、、もういちどいって？"
        robot_SpeechGenerator.say_singleword(message_R)
        robot_expression_controller.create_mouth_shape(message_R_hiragana)
        whether_isaid = 1
        message = ""




#各システム切断
    robot_SpeechRecognition_controller.disconnect()
    robot_SpeechGenerator.disconnect()
    robot_expression_controller.disconnect()
    robot_body_controller.disconnect()
    print('\nEnd')



